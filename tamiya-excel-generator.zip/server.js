const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const os = require('os');
const ExcelJS = require('exceljs');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const supabase = createClient(
  'https://edgvrwekvnavkhcqwtxa.supabase.co',
  '여기에 입력' // ❗ 실제 서비스 키로 교체하세요. Supabase - Project Settings - API Keys - service_rolesecret 복사하기
);

// 파일 다운로드 경로
app.use('/download', express.static('output'));

// 날짜 포맷 함수
function formatDateOnly(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}`;
}

// 주문서 생성 API
app.post('/generate-excel', async (req, res) => {
  try {
    const orderIds = req.body;
    if (!Array.isArray(orderIds)) return res.status(400).send('Invalid input');

    const { data: orders, error } = await supabase
      .from("orders")
      .select("*")
      .in("order_id", orderIds);

    if (error || !orders) return res.status(500).send("Failed to fetch orders");

    const allItems = orders.flatMap(order =>
      (typeof order.items === 'string' ? JSON.parse(order.items) : order.items || []).map(item => ({
        ...item,
        customer: order.name,
        payment_date: order.payment_date ? formatDateOnly(order.payment_date) : ''
      }))
    );

    const is8Digit = code => /^\d{8}$/.test(code);
    const is5Digit = code => /^\d{5}$/.test(code);

    const items8 = allItems.filter(i => is8Digit(i.code));
    const items5 = allItems.filter(i => is5Digit(i.code));

    const files = [];

    if (items8.length > 0) {
      const f8 = await createExcelFromTemplate(items8, 'templates/TKC00000000-USER-8digit_archive.xlsx', '8digit');
      files.push(...f8);
    }
    if (items5.length > 0) {
      const f5 = await createExcelFromTemplate(items5, 'templates/TKC00000000-USER-5digit_archive.xlsx', '5digit');
      files.push(...f5);
    }

    res.json({ files });
  } catch (e) {
    console.error('❌ 서버 오류:', e);
    res.status(500).send('Internal Server Error');
  }
});

// 주문서 엑셀 생성 함수
async function createExcelFromTemplate(items, templatePath, tag) {
  const outputDir = 'output';
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(templatePath);
  const sheet = workbook.getWorksheet(1);

  const now = new Date();
  const yymmdd = `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const mmddyyyy = `${String(now.getMonth() + 1).padStart(2, '0')}/${String(now.getDate()).padStart(2, '0')}/${now.getFullYear()}`;
  const a2value = `TKC${yymmdd}-USER-${tag}`;

  console.log(`✅ DB에서 가격 정보 조회 시작`);
  const codes = [...new Set(items.map(i => Number(i.code)))];
  const { data: itemData, error: itemError } = await supabase
    .from('tamiya_items')
    .select('item_code, j_retail, price')
    .in('item_code', codes);

  if (itemError || !itemData) {
    console.error('❌ Supabase 조회 실패:', itemError);
    throw new Error('제품 가격 정보를 가져오는 데 실패했습니다.');
  }

  const itemMap = new Map();
  itemData.forEach(row => {
    itemMap.set(row.item_code, {
      j_retail: Number(row.j_retail),
      price: Number(row.price)
    });
  });
  console.log(`✅ 가격 정보 ${itemMap.size}건 조회 완료`);

  const startRow = 2;
  const extraRows = items.length - 1;
  if (extraRows > 0) {
    sheet.spliceRows(startRow + 1, 0, ...Array(extraRows).fill([]));
  }

  const templateRow = sheet.getRow(2);
  let totalQty = 0;
  let totalAmount = 0;

  function copyRowStyle(sourceRow, targetRow) {
    sourceRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      const targetCell = targetRow.getCell(colNumber);
      targetCell.value = null;
      targetCell.font = cell.font ? { ...cell.font } : undefined;
      targetCell.alignment = cell.alignment ? { ...cell.alignment } : undefined;
      targetCell.fill = cell.fill ? { ...cell.fill } : undefined;
      targetCell.numFmt = cell.numFmt;
      targetCell.border = undefined;
    });
  }

  console.log(`✅주문 항목 ${items.length}건 처리 시작`);
  items.forEach((item, i) => {
    const rowIndex = startRow + i;
    const row = sheet.getRow(rowIndex);
    row.height = 17;
    copyRowStyle(templateRow, row);

    const itemCode = Number(item.code);
    const dbItem = itemMap.get(itemCode) || {};
    const j_retail = dbItem.j_retail || 0;
    const price = dbItem.price || 0;
    const qty = Number(item.qty || 0);
    const amount = price * qty;

    row.getCell('D').value = itemCode;
    row.getCell('E').value = item.name || '';
    row.getCell('H').value = j_retail;
    row.getCell('I').value = price;
    row.getCell('K').value = qty;
    row.getCell('U').value = { formula: `I${rowIndex}*K${rowIndex}`, result: amount };
    row.getCell('V').value = `${item.code} ${item.customer} ${item.payment_date || ''}`;

    totalQty += qty;
    totalAmount += amount;

    console.log(`✅[${i + 1}] ${itemCode} - ${item.name} (${qty}개)`);
    row.commit();
  });

  const totalRow = startRow + items.length;
  const total = sheet.getRow(totalRow);
  total.getCell('I').value = 'Total';
  total.getCell('K').value = {
    formula: `SUM(K${startRow}:K${totalRow - 1})`,
    result: totalQty
  };
  total.getCell('U').value = {
    formula: `SUM(U${startRow}:U${totalRow - 1})`,
    result: totalAmount
  };
  total.commit();

  console.log(`✅총 수량: ${totalQty}, 총 금액: ${totalAmount}`);

  sheet.getColumn('B').eachCell({ includeEmpty: true }, cell => {
    cell.border = {
      right: { style: 'thin', color: { argb: 'FF000000' } }
    };
  });

  ['F','G','J','L','M','N','O','P','Q','R'].forEach(col => {
    const colIdx = sheet.getColumn(col).number;
    if (colIdx) sheet.getColumn(colIdx).hidden = true;
  });

  const hyunRow = totalRow + 2;
  const imageId = workbook.addImage({
    filename: './images/signtamiya.png',
    extension: 'png'
  });

  sheet.addImage(imageId, {
    tl: { col: 4, row: hyunRow + 1 },
    ext: { width: 180, height: 48 }
  });

  try {
    sheet.unMergeCells('A2');
    sheet.unMergeCells('B2');
  } catch (e) {
    console.warn('병합 해제 실패 (무시 가능):', e.message);
  }

  const a2 = sheet.getCell('A2');
  a2.value = a2value;
  a2.font = undefined;

  const b2 = sheet.getCell('B2');
  b2.value = mmddyyyy;
  b2.font = { name: 'Arial', size: 11 };

  console.log('✅ A2, B2 정보 입력 완료:', a2value, mmddyyyy);

  const archiveFileName = `${a2value}_보관용.xlsx`;
  const archivePath = path.join(outputDir, archiveFileName);
  await workbook.xlsx.writeFile(archivePath);

  sheet.getColumn('V').eachCell((cell, rowNumber) => {
    if (rowNumber >= startRow && rowNumber <= totalRow) cell.value = '';
  });
  const cleanFileName = `${a2value}.xlsx`;
  const cleanPath = path.join(outputDir, cleanFileName);
  await workbook.xlsx.writeFile(cleanPath);

  return [
  path.join(outputDir, archiveFileName),
  path.join(outputDir, cleanFileName)
];
}

// 서버 실행
app.listen(3001, () => {
  console.log('✅ 서버 실행됨: http://localhost:3001');
});
